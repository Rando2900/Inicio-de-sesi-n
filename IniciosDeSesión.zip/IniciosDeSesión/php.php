<?php
$db_host="localhost:3307";
$db_nombre="form_bd";
$db_usuario="root";
$db_contra="";

$conexion = mysqli_connect($db_host,$db_usuario,$db_contra,$db_nombre);
$nombre = $_POST['Nombre'];
$apellido = $_POST['Apellido'];
$email = $_POST['Email'];
$fecha_nac = $_POST['Fecha_nac'];
$contraseña =  md5($_POST['Contraseña']);




$consulta = "INSERT INTO usuarios (nombre, apellido, email, fecha_nacimiento, contraseña) VALUES ('$nombre', '$apellido', '$email', '$fecha_nac', '$contraseña')";
mysqli_query($conexion, $consulta);

mysqli_close($conexion);
?>